package com.infy.ekart.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.infy.ekart.model.DealsForToday;

public class DealsForTodayValidator {
	
	public static void validateDeals(DealsForToday deal) throws Exception 
	{
		if(!validateDealDate(deal.getDealStarts(),deal.getDealEnd()))
			throw new Exception("DealsForTodayValidator.INVALID_DATES");
		if(!validateDealTime(deal.getDealStarts(),deal.getDealEnd()))
			throw new Exception("DealsForTodayValidator.INVALID_TIME");
		
	}
	public static Boolean validateDealDate(LocalDateTime start,LocalDateTime end)
	{
		LocalDate sDate=start.toLocalDate();
		LocalDate eDate=end.toLocalDate();
		if ((sDate.equals(eDate)) && (start.getMonthValue()<=(LocalDateTime.now().getMonthValue()+1)))
			return true;
		
		return false;
		
	}
	public static Boolean validateDealTime(LocalDateTime start,LocalDateTime end)
	{
		if (end.isBefore(start))
			return false;
		
		return true;
		
	}

}
