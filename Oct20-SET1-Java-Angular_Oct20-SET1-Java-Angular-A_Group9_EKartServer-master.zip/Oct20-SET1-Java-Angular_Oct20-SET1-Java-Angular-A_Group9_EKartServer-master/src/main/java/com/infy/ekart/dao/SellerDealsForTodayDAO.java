package com.infy.ekart.dao;

import java.util.List;

import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;

public interface SellerDealsForTodayDAO {
	public Integer addNewDeal(DealsForToday deal);
	public List<DealsForToday> displayProductDeals(String sellerEmailId);
	public Integer removeProductsFromDeals(Integer dealId);
}
