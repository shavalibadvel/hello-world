package com.infy.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="EK_DEALS_FOR_TODAY")
public class DealsForTodayEntity {

	@Id
	@Column(name="DEAL_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer dealId;
	@OneToOne(cascade = CascadeType.ALL,  orphanRemoval = true)
	@JoinColumn(name="PRODUCT_ID")
	private ProductEntity product;
	@Column(name="DEAL_DISCOUNT")
	private double dealDiscount;
	@Column(name="DEAL_STARTS_AT")
	private LocalDateTime dealStarts;
	@Column(name="DEAL_ENDS_AT")
	private LocalDateTime dealEnd;
	@ManyToOne(cascade =CascadeType.ALL )
	@JoinColumn(name="SELLER_EMAIL_ID")
	private SellerEntity sellerEntity;
	
	public SellerEntity getSellerEntity() {
		return sellerEntity;
	}
	public void setSellerEntity(SellerEntity sellerEntity) {
		this.sellerEntity = sellerEntity;
	}
	public Integer getDealId() {
		return dealId;
	}
	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}
	
	
	public ProductEntity getProduct() {
		return product;
	}
	public void setProduct(ProductEntity product) {
		this.product = product;
	}
	public double getDealDiscount() {
		return dealDiscount;
	}
	public void setDealDiscount(double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}
	public LocalDateTime getDealStarts() {
		return dealStarts;
	}
	public void setDealStarts(LocalDateTime dealStarts) {
		this.dealStarts = dealStarts;
	}
	public LocalDateTime getDealEnd() {
		return dealEnd;
	}
	public void setDealEnd(LocalDateTime dealEnd) {
		this.dealEnd = dealEnd;
	}
	
	
}
