package com.infy.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.ekart.entity.DealsForTodayEntity;
import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.entity.SellerEntity;
import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.Seller;

@Repository(value = "SellerProductDAO")
@Transactional
public class SellerDealsForTodayDAOImpl implements SellerDealsForTodayDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public Integer addNewDeal(DealsForToday deals) {
		SellerEntity sellerEntity = entityManager.find(SellerEntity.class, deals.getSeller().getEmailId());
		DealsForTodayEntity newDeal = new DealsForTodayEntity();
		
		newDeal.setDealDiscount(deals.getDealDiscount());
		newDeal.setDealStarts(deals.getDealStarts());
		newDeal.setDealEnd(deals.getDealEnd());
		
		Query qery = entityManager.createQuery("select d from DealsForTodayEntity d");
		List<DealsForTodayEntity> de=qery.getResultList(); 
		boolean isDealAvailable = de.stream()
				.anyMatch(delerEntity -> getDealerMatchedDealEntity(deals, delerEntity));
		if (!isDealAvailable) {

			ProductEntity productEntity = sellerEntity.getProductEntities().stream()
					.filter(sellerProductEntity -> getDealerMatchedProductEntity(deals, sellerProductEntity))
					.findFirst().orElse(null);

			if (productEntity != null ) {
				newDeal.setProduct(productEntity);
				System.out.println("sellerEntity");
				newDeal.setSellerEntity(sellerEntity);
				entityManager.persist(newDeal);


				return newDeal.getDealId();
			}

			else {
				return -1;
			}
		} else {
			return 0;
		}

	}

	private boolean getDealerMatchedDealEntity(DealsForToday deals, DealsForTodayEntity delerEntity) {
		return delerEntity.getProduct().getProductId().equals(deals.getProduct().getProductId());
	}

	private boolean getDealerMatchedProductEntity(DealsForToday deals, ProductEntity sellerProductEntity) {
		return deals.getProduct().getProductId().equals( sellerProductEntity.getProductId());
	}

	@Override
	public List<DealsForToday> displayProductDeals(String sellerEmailId) {

		Query qery = entityManager.createQuery("select d from DealsForTodayEntity d where d.sellerEntity.emailId = :mailId");
		qery.setParameter("mailId", sellerEmailId);

		List<DealsForTodayEntity> dealForTodayEntity = qery.getResultList();
		List<DealsForToday> dealForToday = new ArrayList<DealsForToday>();

		for (DealsForTodayEntity dEntity : dealForTodayEntity) 
		{
			DealsForToday d = new DealsForToday();
			d.setDealDiscount(dEntity.getDealDiscount());
			d.setDealStarts(dEntity.getDealStarts());
			d.setDealEnd(dEntity.getDealEnd());
			d.setDealId(dEntity.getDealId());
			Product p = new Product();
			p.setBrand(dEntity.getProduct().getBrand());
			p.setName(dEntity.getProduct().getName());
			p.setPrice(dEntity.getProduct().getPrice());
			p.setDiscount(dEntity.getProduct().getDiscount());
			p.setProductId(dEntity.getProduct().getProductId());
			p.setDescription(dEntity.getProduct().getDescription());
			p.setCategory(dEntity.getProduct().getCategory());
			p.setQuantity(dEntity.getProduct().getQuantity());

			d.setProduct(p);

			Seller s = new Seller();
			s.setEmailId(dEntity.getSellerEntity().getEmailId());
			d.setSeller(s);
			dealForToday.add(d);
		}
		System.out.println("inside DAO-->"+dealForToday.size());
		return dealForToday;

	}

	@Override
	public Integer removeProductsFromDeals(Integer dealId) {

		DealsForTodayEntity dealsForTodayEntity = entityManager.find(DealsForTodayEntity.class, dealId);
		Integer result = -1;
		if (dealsForTodayEntity != null) {
			result = dealsForTodayEntity.getDealId();
			String querey= "Delete DealsForTodayEntity where dealId= :dealId";
			Query createQuery = entityManager.createQuery(querey);
			createQuery.setParameter("dealId", dealId);
			int executeUpdate = createQuery.executeUpdate();
			//entityManager.getTransaction().commit();
		}
		return result;
	}

}
