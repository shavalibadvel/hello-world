package com.infy.ekart.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.ekart.entity.DealsForTodayEntity;
import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.Seller;
@Repository(value = "customerProductDAO")
public class CustomerProductDAOImpl implements CustomerProductDAO {
	
	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Product> getAllProducts() {

		Query query = entityManager.createQuery("select p from ProductEntity p");
		
		List<ProductEntity> productEntityList= query.getResultList();
		
		List<Product> listOfProducts = new ArrayList<Product>();
		for (ProductEntity productEntity : productEntityList) {
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			product.setDiscount(productEntity.getDiscount());

			listOfProducts.add(product);
		}
		
		return listOfProducts;
	}

	@Override
	public List<DealsForToday> getAllDealsForTodayProducts() throws Exception {
		// TODO Auto-generated method stub
		
		Query query=entityManager.createQuery("select p from DealsForTodayEntity p");
		List<DealsForTodayEntity> DealsForTodayEntityList=query.getResultList();
		List<DealsForTodayEntity> DealsForTodayEntityList1=new ArrayList<DealsForTodayEntity>();
		List<DealsForToday> listOfDealProducts=new ArrayList<DealsForToday>();
	    if(DealsForTodayEntityList.isEmpty())
	    {
	    	throw new Exception("No deals");
	    }
	    else
	    {
		for(DealsForTodayEntity DealsEntity:DealsForTodayEntityList)
	    {  
			
			DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate today =LocalDate.parse(LocalDate.now().format(format));
			LocalDate starts=LocalDate.parse(DealsEntity.getDealStarts().format(format));
			LocalDate ends=LocalDate.parse(DealsEntity.getDealEnd().format(format));
		    System.out.println(today +" "+starts+" "+ends);
			
	    	if(starts.equals(today) && ends.equals(today))
	    	{
	    		DealsForTodayEntityList1.add(DealsEntity);
	    	
	    				    	

	    	}
	    	
	    }
		if(DealsForTodayEntityList1.isEmpty())
		{
			throw new Exception("No deals for today");
		}
		else
		{
			for(DealsForTodayEntity dealsEntity1:DealsForTodayEntityList1)
			{
				DealsForToday dealsForToday=new DealsForToday();
		    	Product product =new Product();
		    	dealsForToday.setDealId(dealsEntity1.getDealId());
		    	dealsForToday.setDealDiscount(dealsEntity1.getDealDiscount());
		    	dealsForToday.setDealStarts(dealsEntity1.getDealStarts());
		    	dealsForToday.setDealEnd(dealsEntity1.getDealEnd());
		    	Seller seller=new Seller();
		    	seller.setAddress(dealsEntity1.getSellerEntity().getAddress());
		    	seller.setName(dealsEntity1.getSellerEntity().getName());
		    	seller.setPhoneNumber(dealsEntity1.getSellerEntity().getPhoneNumber());
		    	seller.setEmailId(dealsEntity1.getSellerEntity().getEmailId());
		    	dealsForToday.setSeller(seller);
		    	product.setProductId(dealsEntity1.getProduct().getProductId());
		    	product.setName(dealsEntity1.getProduct().getName());
		    	product.setDescription(dealsEntity1.getProduct().getDescription());
		    	product.setBrand(dealsEntity1.getProduct().getBrand());
		    	product.setPrice(dealsEntity1.getProduct().getPrice());
		    	product.setDiscount(dealsEntity1.getProduct().getDiscount());
		    	product.setQuantity(dealsEntity1.getProduct().getQuantity());
		    	product.setCategory(dealsEntity1.getProduct().getCategory());
		    	dealsForToday.setProduct(product);
		    	
		    	DateTimeFormatter format1=DateTimeFormatter.ofPattern("HH:mm:ss");
		    	LocalTime time=LocalTime.parse(LocalTime.now().format(format1));
		    	
		    	LocalTime getDealEndTime=LocalTime.parse(dealsEntity1.getDealEnd().format(format1));
		    	LocalTime getDealStartTime=LocalTime.parse(dealsEntity1.getDealStarts().format(format1));
		        if(getDealEndTime.isBefore(time))
		        {
		        	dealsForToday.setStatus("Deal ended");
		        }
		        if(getDealEndTime.isAfter(time))
		        {
		                 dealsForToday.setStatus("Deal is on");    ;
		  		}
		    	if(getDealStartTime.isAfter(time))
		    	{
		    	dealsForToday.setStatus("Deal yet to start");
		    	}
		    	listOfDealProducts.add(dealsForToday);

			}
			
		}
		
	    		    }
		
		return listOfDealProducts;
	}
}
