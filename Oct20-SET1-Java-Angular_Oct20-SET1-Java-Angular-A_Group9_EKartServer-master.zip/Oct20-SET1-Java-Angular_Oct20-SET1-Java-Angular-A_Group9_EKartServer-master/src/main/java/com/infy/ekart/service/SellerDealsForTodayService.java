package com.infy.ekart.service;

import java.util.List;

import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;

public interface SellerDealsForTodayService {
	public Integer addNewDeal(DealsForToday deal) throws Exception;
	public List<DealsForToday> displayProductDeals(String sellerEmailId) throws Exception ;
	public Integer removeProductsFromDeals(Integer dealId)throws Exception;
}
