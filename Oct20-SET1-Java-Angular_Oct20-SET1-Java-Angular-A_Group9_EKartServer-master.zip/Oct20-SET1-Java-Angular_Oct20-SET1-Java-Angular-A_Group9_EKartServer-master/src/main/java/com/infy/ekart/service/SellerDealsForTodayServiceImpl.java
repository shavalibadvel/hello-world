package com.infy.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.ekart.dao.SellerDealsForTodayDAO;
import com.infy.ekart.dao.SellerDealsForTodayDAOImpl;
import com.infy.ekart.dao.SellerProductDAO;
import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;
import com.infy.ekart.validator.DealsForTodayValidator;

@Service(value="sellerDealsForTodayService")
public class SellerDealsForTodayServiceImpl implements SellerDealsForTodayService{

	@Autowired
	private SellerDealsForTodayDAO sellerDealsForToday;
	@Override
	public Integer addNewDeal(DealsForToday deal) throws Exception {

		DealsForTodayValidator.validateDeals(deal);
		Integer dealId=sellerDealsForToday.addNewDeal(deal);
		if(dealId==-1)
		{
			throw new Exception("SellerDealsForTodayService.INVALID_PRODUCT_ID");
		}
		if (dealId==0)
		{
			throw new Exception("SellerDealsForTodayService.DEAL_EXIST");
		}
		return dealId;
		
	}
	@Override
	public List<DealsForToday> displayProductDeals(String sellerEmailId) throws Exception 
	{
		 return sellerDealsForToday.displayProductDeals(sellerEmailId);
	}
	@Override
	public Integer removeProductsFromDeals(Integer dealId){
		return sellerDealsForToday.removeProductsFromDeals(dealId);
	}

}
