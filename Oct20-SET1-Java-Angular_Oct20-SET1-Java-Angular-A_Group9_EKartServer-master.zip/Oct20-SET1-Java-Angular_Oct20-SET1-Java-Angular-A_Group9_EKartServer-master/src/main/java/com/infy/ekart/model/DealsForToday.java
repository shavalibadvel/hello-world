package com.infy.ekart.model;

import java.time.LocalDateTime;

public class DealsForToday {
	private Integer dealId;
	private Product product;
	private double dealDiscount;
	private LocalDateTime dealStarts;
	private LocalDateTime dealEnd;
	private Seller seller;
	private String status;

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public double getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public LocalDateTime getDealStarts() {
		return dealStarts;
	}

	public void setDealStarts(LocalDateTime dealStarts) {
		this.dealStarts = dealStarts;
	}

	public LocalDateTime getDealEnd() {
		return dealEnd;
	}

	public void setDealEnd(LocalDateTime dealEnd) {
		this.dealEnd = dealEnd;
	}

	
	

}
