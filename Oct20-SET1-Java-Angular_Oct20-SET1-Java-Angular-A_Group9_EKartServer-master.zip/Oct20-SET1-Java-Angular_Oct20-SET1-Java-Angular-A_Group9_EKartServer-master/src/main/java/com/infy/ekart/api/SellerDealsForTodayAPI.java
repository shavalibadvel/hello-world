package com.infy.ekart.api;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;
import com.infy.ekart.service.SellerDealsForTodayService;

@RestController
@CrossOrigin
@RequestMapping("SellerDealsForTodayAPI")
public class SellerDealsForTodayAPI {
	@Autowired
	private SellerDealsForTodayService sellerDealsForTodayService;
	@Autowired
	private Environment environment;
	static Logger logger = LogManager.getLogger(SellerProductAPI.class.getName());

	@PostMapping(value = "addNewDealToDealsForTodayCatalog")
	public ResponseEntity<Integer> addNewDealToDealsForTodayCatalog(@RequestBody DealsForToday deal) throws Exception {
		try {
			logger.info("ADDING DEAL TO DEALER CATALOG, PRODUCT DEAL NAME " + deal.getProduct().getName()
					+ "\tDELLER NAME IS " + deal.getSeller().getEmailId());
			Integer newDealId = sellerDealsForTodayService.addNewDeal(deal);
			
				logger.info("PRODUCT DEAL ADDED SUCCESFULLY TO DEALER CATALOG,PRODUCT DEAL NAME:"
						+ deal.getProduct().getName() + "\t DEALER NAME" + deal.getSeller().getEmailId());
				String successMessage = environment.getProperty("SellerDealsForTodayAPI.PRODUCT_ADDED_SUCCESSFULLY")
						+ newDealId;
				
				deal.setDealId(newDealId);
				return new ResponseEntity<>(newDealId, HttpStatus.OK);
			
		} catch (Exception e) {

			if (e.getMessage().contains("Validator")) {
				throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, environment.getProperty(e.getMessage()));
			}
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}

	}

	@PostMapping(value = "displayDealsForToday")
	public ResponseEntity<List<DealsForToday>> displayDealsForToday(@RequestBody String emailId) throws Exception {

		try {
			List<DealsForToday> productCategories = sellerDealsForTodayService.displayProductDeals(emailId);
			return new ResponseEntity<List<DealsForToday>>(productCategories, HttpStatus.OK);
		}

		catch (Exception e) {

			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}

	
	@PostMapping(value = "/removeProductsFromDeals")
	public ResponseEntity<Integer> removeProductsFromDeals(@RequestBody Integer dealId) throws Exception {
		Integer result = sellerDealsForTodayService.removeProductsFromDeals(dealId);
		if (result != -1) {
//			String successMessage = "Deal deleted successfully";
			ResponseEntity<Integer> response = new ResponseEntity<Integer>(dealId, HttpStatus.OK);
			return response;

//		} else {
//			String errorMessage = "No such item";
//			ResponseEntity<String> response = new ResponseEntity<String>(errorMessage, HttpStatus.OK);
//			return response;
		}
		return null;
	}
}
