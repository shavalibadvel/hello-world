package com.infy.ekart.dao.test;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dao.SellerDealsForTodayDAO;
import com.infy.ekart.model.DealsForToday;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.Seller;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@Transactional
@Rollback(true)
public class SellerDealsForTodayDaoTest {

	
	@Autowired
	private SellerDealsForTodayDAO sellerDealsDao;
	@Test
	public void addNewDeal() {
		Seller se= new Seller();
		Product pe=new Product();
		DealsForToday de=new DealsForToday();
		se.setEmailId("jack@infosys.com");
		pe.setBrand("Samsung");
		pe.setCategory("Electronics - Mobile");
		pe.setDescription("12MP camera");
		pe.setDiscount(10.0);
		pe.setName("Galaxy");
		pe.setPrice(18500.0);
		pe.setProductId(1005);
		pe.setQuantity(10);
		de.setProduct(pe);
		de.setSeller(se);
		de.setStatus("Deal yet to start");
		de.setDealDiscount(15.0);
		de.setDealEnd(LocalDateTime.now());
		de.setDealStarts(LocalDateTime.now());
		sellerDealsDao.addNewDeal(de);
		Assert.assertTrue(true);
	}
	@Test
	public void displayProductDeals()
	{
		String emaild="jack@infosys.com";
		Assert.assertNotNull(sellerDealsDao.displayProductDeals(emaild));
	}
	@Test
	public void removeProductsFromDeals()
	{
		Seller se= new Seller();
		Product pe=new Product();
		DealsForToday de=new DealsForToday();
		se.setEmailId("jack@infosys.com");
		pe.setBrand("Samsung");
		pe.setCategory("Electronics - Mobile");
		pe.setDescription("12MP camera");
		pe.setDiscount(10.0);
		pe.setName("Galaxy");
		pe.setPrice(18500.0);
		pe.setProductId(1005);
		pe.setQuantity(10);
		de.setProduct(pe);
		de.setSeller(se);
		de.setStatus("Deal yet to start");
		de.setDealId(10000);
		de.setDealDiscount(15.0);
		de.setDealEnd(LocalDateTime.now());
		de.setDealStarts(LocalDateTime.now());
		sellerDealsDao.removeProductsFromDeals(10000);
		Assert.assertTrue(true);		
	}
	
	}
	

