import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealsForTodayComponent } from './deals-for-today.component';

describe('DealsForTodayComponent', () => {
  let component: DealsForTodayComponent;
  let fixture: ComponentFixture<DealsForTodayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealsForTodayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
