export class Rating{
    ratingId:number;
    userName:string;
    productId:number;
    ratings:number;
    comments:String;
}