import { OrderCategoryPipe } from './order-category.pipe';

describe('OrderCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
