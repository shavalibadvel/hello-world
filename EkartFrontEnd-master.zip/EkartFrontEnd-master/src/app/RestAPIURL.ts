export class RestURL{
    static url:string = "http://localhost:5000/";
}